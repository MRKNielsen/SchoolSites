import"./chunk-75Z2AOVW-BzzYECN7.js";import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cyu5G-Tr.js";import"./chunk-DU6HZSFF-BlpgvKzl.js";import"./chunk-P2QGCYS3-_SeE0QXb.js";import"./chunk-PWAF6VOD-BZoBqp8x.js";import"./chunk-GMAD6QVW-hv6IsAru.js";import"./chunk-4HAMMTFA-C6Tl7kEY.js";import"./chunk-GVQU2GXP-Duv4ZYb-.js";import"./chunk-L3NEJ4N5-B2hafvRU.js";import"./chunk-OSK3NFVY-SNGRdtNA.js";import"./mermaid-D_jPUVqz.js";import"./chunk-F27PBJKO-BVIgLGPF.js";import"./chunk-XXDRQBXY-BwqwIlJV.js";import"./chunk-POPQ4Y6H-BB5NNJFE.js";import{r as t,t as n}from"./chunk-SHT3W25Y-BtLGdeDB.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};